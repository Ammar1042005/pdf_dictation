import pytest
from pdf_dictation.chunker import *
from pdf_dictation.controller import Controller, State, Settings
from pdf_dictation.extractor import reading_order, Entry, keep_image
from pdf_dictation import sessions


@pytest.mark.parametrize("w,e", [("a", .5), ("an", .5), ("the", .5), ("cell", 1), ("mitochondria", 1),
                                 ("cell,", 1), ("(cell)", 1), ("book.", 1), ("DNA", .5), ("2025", 1)])
def test_weights(w, e): assert word_weight(w) == e


def test_timing(): assert writing_time(char_count("The cell is large."), 0.75) == 10.5


def test_example_chunks():
    c = TextChunker().create_chunks("The cell membrane controls the movement of substances")
    assert c[0].text == "The cell membrane controls" and c[0].word_units == 3.5 and c[0].character_count == 23
    assert writing_time(c[0].character_count) == 17.25
    assert TextChunker().create_chunks("I am studying mitochondria")[0].word_units == 3.0


def test_words_never_split_and_paragraphs_separate():
    c = TextChunker().create_chunks("electroencephalography\n\nNext para here")
    assert c[0].text == "electroencephalography" and len(c) == 2


def test_sentence_boundary():
    c = TextChunker().create_chunks("The cell is large. Another one here today")
    assert c[0].text == "The cell is large."


class FakeSpeech:
    def __init__(s): s.on = False; s.said = []
    def speak(s, t): s.on = True; s.said.append(t)
    def stop(s): s.on = False
    def is_speaking(s): return s.on


def make(items):
    t = [0.0]; sp = FakeSpeech()
    return Controller(items, sp, Settings(), clock=lambda: t[0]), sp, t


def test_timer_starts_after_speech_and_image_pause():
    ch = TextChunker().create_chunks("The cell membrane controls")  # 23 chars -> 17.25 s
    c, sp, t = make(ch + [ImageItem(1, (0, 0, 200, 200))] + TextChunker().create_chunks("Hello world today"))
    c.start(); assert c.state == State.SPEAKING
    t[0] = 100; c.tick(); assert c.state == State.SPEAKING
    sp.on = False; c.tick(); assert c.state == State.WRITING
    t[0] = 100 + 17; c.tick(); assert c.state == State.WRITING
    t[0] = 100 + 17.3; c.tick(); assert c.state == State.IMAGE_PAUSED
    c.toggle(); assert c.state == State.SPEAKING and sp.said[-1] == "Hello world today"


def test_pause_freezes_and_repeat_restarts():
    c, sp, t = make(TextChunker().create_chunks("The cell membrane controls"))
    c.start(); sp.on = False; c.tick(); t[0] = 10; c.toggle()
    assert c.state == State.PAUSED; t[0] = 500; c.toggle()
    assert c.state == State.WRITING and abs(c.time_left() - 7.25) < 1e-9
    c.repeat(); assert c.state == State.SPEAKING and len(sp.said) == 2 and c.index == 0


def test_reading_order_two_columns():
    E = lambda r, n: Entry(r, "text", n)
    es = [E((0, 0, 600, 50), "title"), E((320, 60, 580, 100), "R1"), E((20, 60, 280, 100), "L1"),
          E((20, 110, 280, 150), "L2")]
    assert [e.payload for e in reading_order(es, 600)] == ["title", "L1", "L2", "R1"]
    assert not keep_image((0, 0, 20, 20), 100, 100)


def test_sessions(tmp_path):
    a, b = tmp_path / "a.pdf", tmp_path / "b.pdf"; a.write_bytes(b"A"); b.write_bytes(b"B")
    sessions.save(str(a), 43, {}, tmp_path)
    assert sessions.load(str(a), tmp_path)["chunk_index"] == 43 and sessions.load(str(b), tmp_path) is None


def test_textprep():
    from pdf_dictation.textprep import prepare_speech as p
    assert p("Figure 3.2 shows it.") == "Figure 3 point 2 shows it."
    assert p("Fig. 1") == "Figure 1"
    assert p("The cell, large.", speak_punctuation=True) == "The cell, comma, large, period,"
    assert p("A, b.", speak_punctuation=False) == "A, b."


def test_settings_roundtrip(tmp_path):
    from pdf_dictation import settings as cfg
    s = cfg.load(tmp_path / "x.json"); assert s.seconds_per_char == 0.75      # missing file -> defaults
    s.seconds_per_char, s.rate = 1.25, 170; cfg.save(s, tmp_path / "x.json")
    r = cfg.load(tmp_path / "x.json"); assert (r.seconds_per_char, r.rate) == (1.25, 170)
    assert r.word_rules().target == 3.0


def test_ocr_helpers():
    from pdf_dictation.extractor import needs_ocr, is_page_scan
    assert needs_ocr([]) and needs_ocr([((0, 0, 1, 1), "  p. 3 ")]) and not needs_ocr([((0, 0, 1, 1), "A real paragraph of text here.")])
    assert is_page_scan((0, 0, 600, 790), (0, 0, 612, 792)) and not is_page_scan((50, 50, 300, 300), (0, 0, 612, 792))


def test_ocr_settings_roundtrip(tmp_path):
    from pdf_dictation import settings as cfg
    s = cfg.load(tmp_path / "o.json"); assert (s.ocr_mode, s.ocr_language) == ("auto", "eng")
    s.ocr_language = "hin"; cfg.save(s, tmp_path / "o.json"); assert cfg.load(tmp_path / "o.json").ocr_language == "hin"
