"""Offline OCR via PyMuPDF's built-in Tesseract bridge (needs the Tesseract program + language data installed)."""


def tessdata():
    try:
        import fitz
        return fitz.get_tessdata()
    except Exception:
        return None


def available(): return tessdata() is not None


def ocr_blocks(page, lang="eng", dpi=200):
    tp = page.get_textpage_ocr(language=lang, dpi=dpi, full=True, tessdata=tessdata())
    return [(tuple(b[:4]), b[4]) for b in page.get_text("blocks", textpage=tp) if b[6] == 0 and b[4].strip()]
