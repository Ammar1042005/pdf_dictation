from dataclasses import replace
from PySide6.QtWidgets import (QDialog, QFormLayout, QDialogButtonBox, QDoubleSpinBox, QSpinBox, QCheckBox,
                               QComboBox, QLineEdit, QPushButton, QLabel, QVBoxLayout)
from pdf_dictation.speech import SpeechEngine


def _dspin(lo, hi, v, step=0.25):
    w = QDoubleSpinBox(); w.setRange(lo, hi); w.setSingleStep(step); w.setDecimals(2); w.setValue(v); return w


class SettingsDialog(QDialog):
    def __init__(self, s, voices, parent=None):
        super().__init__(parent); self.setWindowTitle("Settings"); self.s = s
        f = QFormLayout()
        self.spc = _dspin(0.05, 5, s.seconds_per_char); self.extra = _dspin(0, 30, s.extra_pause, 1)
        self.target = _dspin(1, 10, s.target, 0.5); self.sw = _dspin(0, 5, s.short_weight, 0.25)
        self.lw = _dspin(0, 5, s.long_weight, 0.25)
        self.smax = QSpinBox(); self.smax.setRange(1, 10); self.smax.setValue(s.short_max)
        self.voice = QComboBox(); self.voice.addItem("System default", "")
        for vid, name in voices: self.voice.addItem(name, vid)
        i = self.voice.findData(s.voice_id); self.voice.setCurrentIndex(max(i, 0))
        self.rate = QSpinBox(); self.rate.setRange(60, 350); self.rate.setValue(s.rate)
        self.vol = _dspin(0, 1, s.volume, 0.1)
        test = QPushButton("Test Voice"); test.clicked.connect(self.test_voice)
        self.pimg = QCheckBox("Pause at images"); self.pimg.setChecked(s.pause_at_images)
        self.iw = QSpinBox(); self.iw.setRange(0, 2000); self.iw.setValue(s.min_img_w)
        self.ih = QSpinBox(); self.ih.setRange(0, 2000); self.ih.setValue(s.min_img_h)
        self.punct = QCheckBox("Speak punctuation"); self.punct.setChecked(s.speak_punctuation)
        self.norm = QCheckBox("Normalize abbreviations/numbers"); self.norm.setChecked(s.normalize)
        self.ocr = QComboBox(); self.ocr.addItems(["auto", "off"]); self.ocr.setCurrentText(s.ocr_mode)
        self.ocrlang = QLineEdit(s.ocr_language)
        for lab, w in (("OCR for scanned pages", self.ocr), ("OCR language (e.g. eng, hin)", self.ocrlang),("Target word-units per chunk", self.target), ("Seconds per character", self.spc),
                       ("Extra pause (s)", self.extra), ("Short word weight", self.sw), ("Long word weight", self.lw),
                       ("Short word max letters", self.smax), ("Voice", self.voice), ("Speech rate", self.rate),
                       ("Volume", self.vol), ("", test), ("", self.pimg), ("Min image width", self.iw),
                       ("Min image height", self.ih), ("", self.punct), ("", self.norm)): f.addRow(lab, w)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(self.accept); bb.rejected.connect(self.reject)
        note = QLabel("Chunk and image settings apply the next time a PDF is opened."); note.setWordWrap(True)
        lay = QVBoxLayout(self); lay.addLayout(f); lay.addWidget(note); lay.addWidget(bb)

    def result_settings(self):
        return replace(self.s, seconds_per_char=self.spc.value(), extra_pause=self.extra.value(),
                       target=self.target.value(), short_weight=self.sw.value(), long_weight=self.lw.value(),
                       short_max=self.smax.value(), voice_id=self.voice.currentData() or "", rate=self.rate.value(),
                       volume=self.vol.value(), pause_at_images=self.pimg.isChecked(), min_img_w=self.iw.value(),
                       min_img_h=self.ih.value(), speak_punctuation=self.punct.isChecked(),
                       normalize=self.norm.isChecked(), ocr_mode=self.ocr.currentText(),
                       ocr_language=self.ocrlang.text().strip() or "eng")

    def test_voice(self):
        r = self.result_settings()
        self._tmp = SpeechEngine(r.rate, r.volume, r.voice_id or None); self._tmp.speak("This is a test of the selected voice.")
