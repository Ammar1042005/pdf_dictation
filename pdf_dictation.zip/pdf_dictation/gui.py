import sys, logging
from pathlib import Path
import fitz
from PySide6.QtCore import QTimer, Qt, QThread, QRectF, Signal
from PySide6.QtGui import QShortcut, QKeySequence, QPixmap, QImage, QPainter, QPen, QColor
from PySide6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel,
                               QPushButton, QFileDialog, QMessageBox, QDoubleSpinBox, QSpinBox, QProgressBar, QProgressDialog)
from pdf_dictation import sessions, settings as cfg
from pdf_dictation.chunker import TextChunker, ImageItem
from pdf_dictation.controller import Controller, Settings, State
from pdf_dictation.extractor import load_items, PdfError
from pdf_dictation.speech import SpeechEngine

from pdf_dictation import paths
logging.basicConfig(filename=str(paths.log_file()), level=logging.INFO)
COLORS = {State.SPEAKING: "#1e88e5", State.WRITING: "#f9a825", State.IMAGE_PAUSED: "#e53935",
          State.PAUSED: "#757575", State.FINISHED: "#43a047"}
LABELS = {State.SPEAKING: "🔊 SPEAKING", State.WRITING: "✍ WRITING", State.IMAGE_PAUSED:
          "⏸ IMAGE DETECTED — press SPACE to continue", State.PAUSED: "⏸ PAUSED",
          State.FINISHED: "✓ FINISHED", State.READY: "READY", State.IDLE: "OPEN A PDF"}


class Loader(QThread):
    """Reads/OCRs the PDF off the GUI thread."""
    progress = Signal(int, int); done = Signal(object); failed = Signal(str)

    def __init__(self, path, s):
        super().__init__(); self.path, self.s = path, s

    def run(self):
        s = self.s

        def prog(i, n):
            if self.isInterruptionRequested(): raise PdfError("Loading cancelled.")
            self.progress.emit(i, n)
        try:
            self.done.emit(load_items(self.path, s.min_img_w, s.min_img_h, TextChunker(s.word_rules()),
                                      s.ocr_mode, s.ocr_language, prog))
        except PdfError as e: self.failed.emit(str(e))
        except Exception as e: self.failed.emit(f"Unexpected error: {e}")


class Win(QMainWindow):
    def __init__(self):
        super().__init__(); self.setWindowTitle("PDF Dictation"); self.ctl = None; self.path = None; self.doc = None
        self.settings = cfg.load(); self.speech = SpeechEngine(); self.apply_speech(); self.pages = 0; self.zoom = 1.2
        w = QWidget(); self.setCentralWidget(w); root = QVBoxLayout(w)
        top = QHBoxLayout(); b = QPushButton("Open PDF…"); b.clicked.connect(self.open_pdf); top.addWidget(b)
        sb = QPushButton("Settings…"); sb.clicked.connect(self.open_settings); top.addWidget(sb)
        self.spc = QDoubleSpinBox(); self.spc.setRange(0.05, 5); self.spc.setSingleStep(0.25)
        self.spc.setValue(self.settings.seconds_per_char); self.spc.valueChanged.connect(lambda v: setattr(self.settings, "seconds_per_char", v))
        self.extra = QDoubleSpinBox(); self.extra.setRange(0, 30); self.extra.setValue(self.settings.extra_pause)
        self.extra.valueChanged.connect(lambda v: setattr(self.settings, "extra_pause", v))
        for lab, sp in (("Sec/char", self.spc), ("Extra pause", self.extra)): top.addWidget(QLabel(lab)); top.addWidget(sp)
        root.addLayout(top)
        # Page navigation controls
        page_nav = QHBoxLayout()
        self.page_spin = QSpinBox(); self.page_spin.setRange(1, 9999); self.page_spin.valueChanged.connect(self.go_to_page)
        self.page_label = QLabel("Page:"); self.page_total = QLabel("/ 0")
        page_nav.addWidget(self.page_label); page_nav.addWidget(self.page_spin); page_nav.addWidget(self.page_total)
        # Zoom controls
        self.zoom_spin = QDoubleSpinBox(); self.zoom_spin.setRange(0.5, 3.0); self.zoom_spin.setSingleStep(0.1); self.zoom_spin.setDecimals(1)
        self.zoom_spin.setValue(self.zoom); self.zoom_spin.valueChanged.connect(self.set_zoom)
        page_nav.addWidget(QLabel("  Zoom:")); page_nav.addWidget(self.zoom_spin)
        page_nav.addStretch()
        root.addLayout(page_nav)
        self.view = QLabel(alignment=Qt.AlignCenter); self.view.setMinimumHeight(300); root.addWidget(self.view, 1)
        self.status = QLabel("OPEN A PDF", alignment=Qt.AlignCenter); self.status.setStyleSheet("font:bold 28px;padding:12px")
        self.chunk = QLabel("", alignment=Qt.AlignCenter, wordWrap=True); self.chunk.setStyleSheet("font-size:22px")
        self.info = QLabel(""); self.bar = QProgressBar(); self.bar.setRange(0, 1000)
        for x in (self.status, self.chunk, self.info, self.bar): root.addWidget(x)
        # On-screen control buttons
        btn_layout = QHBoxLayout()
        self.btn_start = QPushButton("Start"); self.btn_start.clicked.connect(self.on_start_pause)
        self.btn_repeat = QPushButton("Repeat"); self.btn_repeat.clicked.connect(self.on_repeat)
        self.btn_prev = QPushButton("Previous"); self.btn_prev.clicked.connect(self.on_prev)
        self.btn_next = QPushButton("Next"); self.btn_next.clicked.connect(self.on_next)
        for btn in (self.btn_start, self.btn_repeat, self.btn_prev, self.btn_next):
            btn.setMinimumWidth(100); btn_layout.addWidget(btn)
        root.addLayout(btn_layout)
        for key, fn in (("Space", "toggle"), ("R", "repeat"), ("Left", "prev"), ("Right", "next"), ("Esc", "stop"), ("F", "repeat")):
            sc = QShortcut(QKeySequence(key), self); sc.setContext(Qt.ApplicationShortcut)
            sc.activated.connect(lambda f=fn: self.ctl and getattr(self.ctl, f)())
        # +/- for speech rate adjustment
        for key, delta in (("+", 10), ("-", -10)):
            sc = QShortcut(QKeySequence(key), self); sc.setContext(Qt.ApplicationShortcut)
            sc.activated.connect(lambda d=delta: self.adjust_rate(d))
        t = QTimer(self); t.timeout.connect(self.tick); t.start(100)

    def open_pdf(self):
        p, _ = QFileDialog.getOpenFileName(self, "PDF", "", "PDF (*.pdf)")
        if not p: return
        dlg = QProgressDialog("Reading PDF (scanned pages are OCR'd, this can take a while)…", "Cancel", 0, 100, self)
        dlg.setWindowModality(Qt.WindowModal); dlg.setMinimumDuration(500)
        self.loader = Loader(p, self.settings)
        self.loader.progress.connect(lambda i, n: (dlg.setMaximum(n), dlg.setValue(i)))
        self.loader.failed.connect(lambda m: (dlg.close(), QMessageBox.critical(self, "Error", m)))
        self.loader.done.connect(lambda res: (dlg.close(), self.on_loaded(p, res)))
        dlg.canceled.connect(self.loader.requestInterruption)
        self.loader.start()

    def on_loaded(self, p, res):
        self.pages, self.doc, self.path = res.pages, fitz.open(p), p
        self.page_spin.setRange(1, self.pages); self.page_total.setText(f"/ {self.pages}")
        if res.ocr_pages:
            QMessageBox.information(self, "OCR used", f"{res.ocr_pages} scanned page(s) were read with OCR. "
                                    "Accuracy depends on scan quality; check the preview if a chunk sounds wrong.")
        self.ctl = Controller(res.items, self.speech, self.settings, on_change=self.refresh)
        s = sessions.load(p)
        if s and QMessageBox.question(self, "Resume", "Resume from previous position?") == QMessageBox.Yes:
            self.ctl.index = min(s["chunk_index"], len(res.items) - 1)
        self.refresh()

    def tick(self):
        if not self.ctl: return
        self.ctl.tick()
        if self.ctl.state == State.WRITING:
            tot = max(0.001, self.ctl.item.character_count * self.settings.seconds_per_char + self.settings.extra_pause)
            self.bar.setValue(int(1000 * (1 - self.ctl.time_left() / tot)))
            self.status.setText(f"✍ WRITING  {self.ctl.time_left():.1f}s")

    def refresh(self):
        c = self.ctl; st = c.state; it = c.item
        self.status.setText(LABELS[st]); self.status.setStyleSheet(
            f"font:bold 28px;padding:12px;color:white;background:{COLORS.get(st, '#455a64')}")
        if it is not None:
            self.chunk.setText("[IMAGE]" if isinstance(it, ImageItem) else it.text)
            self.info.setText(f"Page {it.page_number} / {self.pages}   Item {c.index + 1} / {len(c.items)}"
                              + ("" if isinstance(it, ImageItem) else f"   Writing time: {c.remaining or 0:.2f}s"))
            self.show_page(it)
            # Sync page spinner with current chunk's page
            if self.page_spin.value() != it.page_number:
                self.page_spin.blockSignals(True)
                self.page_spin.setValue(it.page_number)
                self.page_spin.blockSignals(False)
        if self.path: sessions.save(self.path, c.index, {"seconds_per_character": self.settings.seconds_per_char})
        # Update button states
        self.btn_start.setText("Pause" if st in (State.SPEAKING, State.WRITING) else "Resume" if st == State.PAUSED else "Start")
        self.btn_start.setEnabled(self.ctl is not None and st != State.IDLE and st != State.FINISHED)
        self.btn_repeat.setEnabled(self.ctl is not None and st != State.IDLE and st != State.FINISHED and not isinstance(it, ImageItem))
        self.btn_prev.setEnabled(self.ctl is not None and c.index > 0)
        self.btn_next.setEnabled(self.ctl is not None and c.index < len(c.items) - 1)

    def apply_speech(self):
        s = self.settings; self.speech.rate, self.speech.volume, self.speech.voice_id = s.rate, s.volume, s.voice_id or None

    def open_settings(self):
        d = SettingsDialog(self.settings, self.speech.voices(), self)
        if d.exec():
            for k, v in vars(d.result_settings()).items(): setattr(self.settings, k, v)  # in place: controller sees it
            cfg.save(self.settings); self.apply_speech()
            self.spc.setValue(self.settings.seconds_per_char); self.extra.setValue(self.settings.extra_pause)

    def show_page(self, it, highlight=True):
        if not self.doc: return
        page, z = self.doc[it.page_number - 1], self.zoom
        pix = page.get_pixmap(matrix=fitz.Matrix(z, z))
        pm = QPixmap.fromImage(QImage(pix.samples, pix.width, pix.height, pix.stride, QImage.Format_RGB888).copy())
        if highlight:
            p = QPainter(pm)
            if isinstance(it, ImageItem):
                p.setPen(QPen(QColor("#e53935"), 5)); rects = [it.bbox]
            else:
                p.setPen(Qt.NoPen); p.setBrush(QColor(255, 235, 59, 120))
                try: found = [tuple(r) for r in page.search_for(it.text) if fitz.Rect(r).intersects(fitz.Rect(it.bbox))] if it.bbox else []
                except Exception: found = []
                rects = found or ([it.bbox] if it.bbox else [])   # exact words, else the whole block (e.g. OCR pages)
            for r in rects: p.drawRect(QRectF(r[0] * z, r[1] * z, (r[2] - r[0]) * z, (r[3] - r[1]) * z))
            p.end()
        self.view.setPixmap(pm.scaledToHeight(max(300, self.view.height()), Qt.SmoothTransformation))

    def on_start_pause(self):
        if self.ctl: self.ctl.toggle()

    def on_repeat(self):
        if self.ctl: self.ctl.repeat()

    def on_prev(self):
        if self.ctl: self.ctl.prev()

    def on_next(self):
        if self.ctl: self.ctl.next()

    def adjust_rate(self, delta):
        new_rate = max(60, min(350, self.settings.rate + delta))
        if new_rate != self.settings.rate:
            self.settings.rate = new_rate
            self.apply_speech()
            cfg.save(self.settings)

    def go_to_page(self, page_num):
        if not self.doc or page_num < 1 or page_num > self.pages: return
        page = self.doc[page_num - 1]
        pix = page.get_pixmap(matrix=fitz.Matrix(self.zoom, self.zoom))
        pm = QPixmap.fromImage(QImage(pix.samples, pix.width, pix.height, pix.stride, QImage.Format_RGB888).copy())
        self.view.setPixmap(pm.scaledToHeight(max(300, self.view.height()), Qt.SmoothTransformation))

    def set_zoom(self, zoom_level):
        self.zoom = zoom_level
        if self.ctl and self.ctl.item:
            self.show_page(self.ctl.item)


def main():
    a = QApplication(sys.argv); a.setApplicationName("PDF Dictation")
    w = Win(); w.resize(900, 800); w.show(); sys.exit(a.exec())


if __name__ == "__main__":
    main()
