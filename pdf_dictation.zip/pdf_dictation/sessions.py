import hashlib, json, logging
from pathlib import Path
from pdf_dictation import paths
log = logging.getLogger("pdf_dictation")
DIR = paths.data_dir() / "sessions"


def pdf_hash(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""): h.update(b)
    return h.hexdigest()


def save(path, index, settings: dict, directory=DIR):
    try:
        directory.mkdir(parents=True, exist_ok=True); h = pdf_hash(path)
        (directory / f"{h}.json").write_text(json.dumps({"pdf_hash": h, "chunk_index": index, "settings": settings}))
    except Exception as e: log.error("session save failed: %s", e)


def load(path, directory=DIR):
    try:
        h = pdf_hash(path); d = json.loads((directory / f"{h}.json").read_text())
        return d if d.get("pdf_hash") == h else None
    except Exception: return None
