"""Qt-free dictation state machine. Drive it by calling tick() every ~100 ms."""
import time
from enum import Enum
from dataclasses import dataclass
from .chunker import ImageItem, WordRules, writing_time
from .textprep import prepare_speech


class State(Enum):
    IDLE = "IDLE"; READY = "READY"; SPEAKING = "SPEAKING"; WRITING = "WRITING"
    PAUSED = "PAUSED"; IMAGE_PAUSED = "IMAGE_PAUSED"; FINISHED = "FINISHED"; ERROR = "ERROR"


@dataclass
class Settings:
    seconds_per_char: float = 0.75
    extra_pause: float = 0.0
    pause_at_images: bool = True
    speak_punctuation: bool = False
    normalize: bool = True
    target: float = 3.0
    short_weight: float = 0.5
    long_weight: float = 1.0
    short_max: int = 3
    min_img_w: int = 100
    min_img_h: int = 100
    voice_id: str = ""
    rate: int = 150
    volume: float = 1.0
    ocr_mode: str = "auto"      # "auto" | "off"
    ocr_language: str = "eng"

    def word_rules(self):
        return WordRules(self.short_weight, self.long_weight, self.short_max, self.target)


class Controller:
    def __init__(self, items, speech, settings=None, clock=time.monotonic, on_change=None):
        self.items, self.speech = items, speech
        self.s = settings or Settings()
        self.clock, self.on_change = clock, on_change or (lambda: None)
        self.index, self.state = 0, State.READY if items else State.IDLE
        self.remaining, self.deadline, self._paused_from = 0.0, 0.0, None

    @property
    def item(self): return self.items[self.index] if self.index < len(self.items) else None

    def time_left(self):
        if self.state == State.WRITING: return max(0.0, self.deadline - self.clock())
        return self.remaining

    def _set(self, st): self.state = st; self.on_change()

    def _enter(self):
        it = self.item
        if it is None: return self._set(State.FINISHED)
        if isinstance(it, ImageItem):
            if self.s.pause_at_images: return self._set(State.IMAGE_PAUSED)
            self.index += 1; return self._enter()
        self.remaining = writing_time(it.character_count, self.s.seconds_per_char, self.s.extra_pause)
        self.speech.speak(prepare_speech(it.text, self.s.speak_punctuation, self.s.normalize))
        self._set(State.SPEAKING)

    def tick(self):
        if self.state == State.SPEAKING and not self.speech.is_speaking():
            self.deadline = self.clock() + self.remaining; self._set(State.WRITING)  # timer starts AFTER speech
        elif self.state == State.WRITING and self.clock() >= self.deadline:
            self.index += 1; self.remaining = 0.0; self._enter()

    def start(self):
        if self.state in (State.READY, State.PAUSED): self._enter()

    def toggle(self):
        st = self.state
        if st == State.IMAGE_PAUSED: self.index += 1; self._enter()
        elif st == State.SPEAKING: self.speech.stop(); self._paused_from = st; self._set(State.PAUSED)
        elif st == State.WRITING:
            self.remaining = max(0.0, self.deadline - self.clock())
            self._paused_from = st; self._set(State.PAUSED)
        elif st == State.PAUSED:
            if self._paused_from == State.WRITING:
                self.deadline = self.clock() + self.remaining; self._set(State.WRITING)
            else: self._enter()
            self._paused_from = None
        elif st == State.READY: self.start()

    def repeat(self):
        if isinstance(self.item, ImageItem) or self.item is None: return
        self.speech.stop(); self._enter()   # re-speak, then full timer again

    def _move(self, d):
        n = self.index + d
        if 0 <= n < len(self.items):
            self.speech.stop(); self.index = n; self.remaining = 0.0
            self._paused_from = None; self._set(State.PAUSED)  # waits for user to resume

    def next(self): self._move(1)
    def prev(self): self._move(-1)

    def stop(self):
        self.speech.stop(); self._set(State.READY)
