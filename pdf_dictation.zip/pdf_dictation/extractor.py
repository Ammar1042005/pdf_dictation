"""PDF -> ordered sequence of Chunk / ImageItem (position-aware, with automatic OCR for scanned pages)."""
import logging
from dataclasses import dataclass
from . import ocr
from .chunker import TextChunker, ImageItem

log = logging.getLogger("pdf_dictation")
OCR_HELP = ("This looks like a scanned PDF but OCR is unavailable. Install Tesseract "
            "(Windows: github.com/UB-Mannheim/tesseract, Linux: sudo apt install tesseract-ocr) "
            "and restart; set TESSDATA_PREFIX if it is still not found.")


class PdfError(Exception): pass


@dataclass
class Entry:
    rect: tuple
    kind: str      # "text" | "image"
    payload: object


@dataclass
class Loaded:
    items: list
    pages: int
    ocr_pages: int = 0


def reading_order(entries, page_w):
    """Full-width entries split the page into bands; inside a band: left column, then right."""
    key_y = lambda e: (e.rect[1], e.rect[0])
    out, band = [], []

    def flush():
        L = [e for e in band if (e.rect[0] + e.rect[2]) / 2 < page_w / 2]
        R = [e for e in band if e not in L]
        out.extend(sorted(L, key=key_y) + sorted(R, key=key_y)); band.clear()

    for e in sorted(entries, key=key_y):
        if e.rect[2] - e.rect[0] >= 0.6 * page_w: flush(); out.append(e)
        else: band.append(e)
    flush()
    return out


def keep_image(rect, min_w, min_h): return (rect[2] - rect[0]) >= min_w and (rect[3] - rect[1]) >= min_h
def needs_ocr(blocks): return sum(len(t.strip()) for _, t in blocks) < 20


def is_page_scan(rect, page_rect, frac=0.85):
    """True if an image covers most of the page, i.e. it IS the scan, not a figure."""
    a = max(0, rect[2] - rect[0]) * max(0, rect[3] - rect[1])
    return a >= frac * (page_rect[2] - page_rect[0]) * (page_rect[3] - page_rect[1])


def load_items(path, min_w=100, min_h=100, chunker=None, ocr_mode="auto", ocr_lang="eng", progress=None):
    try:
        import fitz
        doc = fitz.open(path)
    except Exception as e: raise PdfError(f"Cannot open PDF: {e}")
    if doc.needs_pass: raise PdfError("PDF is password-protected.")
    chunker, items, n_ocr, skipped = chunker or TextChunker(), [], 0, 0
    ocr_ok = ocr_mode == "auto" and ocr.available()
    for pno, page in enumerate(doc, 1):
        if progress: progress(pno, len(doc))          # may raise PdfError to cancel
        try:
            blocks = [(tuple(b[:4]), b[4]) for b in page.get_text("blocks") if b[6] == 0 and b[4].strip()]
            scanned = False
            if needs_ocr(blocks) and ocr_mode == "auto":
                if ocr_ok:
                    blocks, scanned = ocr.ocr_blocks(page, ocr_lang), True; n_ocr += 1; log.info("OCR p%d", pno)
                else: skipped += 1
            entries = [Entry(r, "text", t) for r, t in blocks]
            for im in page.get_image_info():
                r = tuple(im["bbox"])
                if keep_image(r, min_w, min_h) and not (scanned and is_page_scan(r, tuple(page.rect))):
                    entries.append(Entry(r, "image", ImageItem(pno, r))); log.info("image p%d", pno)
            for e in reading_order(entries, page.rect.width):
                if e.kind == "image": items.append(e.payload)
                else:
                    new = chunker.create_chunks(e.payload.replace("-\n", "").replace("\n", " "), pno)
                    for c in new: c.bbox = e.rect
                    items.extend(new)
        except Exception as ex: log.error("page %d parse failed: %s", pno, ex)
    if not any(not isinstance(i, ImageItem) for i in items):
        raise PdfError(OCR_HELP if skipped else "No extractable text found in this PDF.")
    log.info("loaded %d items from %d pages (%d OCR)", len(items), len(doc), n_ocr)
    return Loaded(items, len(doc), n_ocr)
