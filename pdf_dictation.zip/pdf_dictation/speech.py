"""Non-blocking offline TTS (pyttsx3). Pause is emulated: stop, then re-speak."""
import threading, logging
try:
    import pythoncom  # Windows COM initialization for SAPI5
except ImportError:
    pythoncom = None


class SpeechEngine:
    def __init__(self, rate=150, volume=1.0, voice_id=None):
        self.rate, self.volume, self.voice_id = rate, volume, voice_id
        self._speaking, self._engine, self._gen = False, None, 0
        self._engine_lock = threading.Lock()
        self._init_engine()

    def _init_engine(self):
        """Initialize the pyttsx3 engine (called once)."""
        try:
            if pythoncom:
                pythoncom.CoInitialize()
            import pyttsx3
            self._engine = pyttsx3.init()
            self._engine.setProperty("rate", self.rate)
            self._engine.setProperty("volume", self.volume)
            if self.voice_id:
                self._engine.setProperty("voice", self.voice_id)
        except Exception as ex:
            logging.getLogger("pdf_dictation").error("TTS init error: %s", ex)

    def voices(self):
        try:
            import pyttsx3
            return [(v.id, v.name) for v in pyttsx3.init().getProperty("voices")]
        except Exception: return []

    def speak(self, text):
        self.stop()
        self._gen += 1; gen = self._gen
        self._speaking = True          # set before thread start: no race with tick()
        threading.Thread(target=self._run, args=(text, gen), daemon=True).start()

    def _run(self, text, gen):
        try:
            with self._engine_lock:
                if self._engine is None:
                    self._init_engine()
                # Update properties in case they changed
                self._engine.setProperty("rate", self.rate)
                self._engine.setProperty("volume", self.volume)
                if self.voice_id:
                    self._engine.setProperty("voice", self.voice_id)
                logging.getLogger("pdf_dictation").info("Speaking: %s", text[:50])
                self._engine.say(text)
                self._engine.runAndWait()
                logging.getLogger("pdf_dictation").info("Finished speaking")
        except Exception as ex:
            logging.getLogger("pdf_dictation").error("TTS error: %s", ex)
        finally:
            if gen == self._gen:
                logging.getLogger("pdf_dictation").info("Setting speaking to False")
                self._speaking = False

    def stop(self):
        self._gen += 1; self._speaking = False
        with self._engine_lock:
            try:
                if self._engine: self._engine.stop()
            except Exception: pass

    def pause(self): self.stop()
    def resume(self): pass   # controller re-speaks the chunk
    def is_speaking(self): return self._speaking
