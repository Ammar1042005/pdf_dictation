"""Speech-friendly text preparation (optional; never changes what counts for timing)."""
import re

NAMES = {",": "comma", ".": "period", ";": "semicolon", ":": "colon", "?": "question mark", "!": "exclamation mark"}


def prepare_speech(text, speak_punctuation=False, normalize=True):
    if normalize:
        text = re.sub(r"\bFig\.", "Figure", text)
        text = re.sub(r"\be\.g\.", "for example", text)
        text = re.sub(r"\bi\.e\.", "that is", text)
        text = re.sub(r"(?<=\d)\.(?=\d)", " point ", text)   # 3.2 -> 3 point 2
    if speak_punctuation:
        text = re.sub(r"([,.;:?!])", lambda m: f", {NAMES[m.group(1)]},", text)
    return text
